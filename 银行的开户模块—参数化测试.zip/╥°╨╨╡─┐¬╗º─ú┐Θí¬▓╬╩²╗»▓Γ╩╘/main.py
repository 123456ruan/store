import unittest
from HTMLTestRunner import HTMLTestRunner
import os
tests = unittest.defaultTestLoader.discover(os.getcwd(),pattern="test*.py")

runner =HTMLTestRunner.HTMLTestRunner(
    title="银行测试报告",
    description="银行开户的测试报告",
    verbosity=1,
    stream=open(file="银行测试报告.html",mode="w+",encoding="utf-8")

)
runner.run(tests)