from unittest import TestCase
from ddt import ddt
from ddt import data
from ddt import unpack
from bank import bank_addUser

da = [
    ["1111", "1", "admin", "123456", "cn", "安徽省", "桃园路", "s001",  1],
    ["2222", "1", "admin", "123456", "cn", "安徽省", "桃园路", "s001",  1],
    ["3333", "1", "admin", "123456", "cn", "安徽省", "桃园路", "s001", 1],
    ["4444", "1", "admin", "123456", "cn", "安徽省", "桃园路", "s001", 1],
    ["1111", "1", "admin", "123456", "cn", "安徽省", "桃园路", "s001",  2],
]
@ddt
class testBank(TestCase):
    @data(*da)
    @unpack
    def testaddUser(self,account, type, name, password, country, province, street, House_number,n):
         sum = bank_addUser(account, type, name, password, country, province, street, House_number)
         self.assertEqual(sum,n)


