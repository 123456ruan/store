class Calc:
    def add(self,a,b):
        return a + b

    def subs(self,a,b):
        return a - b

    def multi(self,a,b):
        return a * b

    def devision(self,a,b):
        return a / b
# 测试方法：边界值、因果法、错误探测法、场景法、等价类

'''
用例的测试阶段：
    1.准备数据
    2.执行用例
    3.对比实际结果与期望结果是否一致，提交bug.
'''
# # 1.
# a = 5
# b = 6
# c = 11
#
# # 2.调用方法，得到实际结果
# calc = Calc()
# sum = calc.add(a,b)
#
# # 3.对比数据
# if sum != c:
#     print("用例不通过！")
# else:
#     print("用例通过！")












