import unittest
from HTMLTestRunner import HTMLTestRunner
import os
from threading import Thread
class Test(Thread):
    py = ""
    name = ""
    def run(self) -> None:
        test = unittest.defaultTestLoader.discover(os.getcwd(), pattern=self.py)
        runner = HTMLTestRunner.HTMLTestRunner(
            title="计算器测试报告",
            description="计算器的测试报告",
            verbosity=1,
            stream=open(file = self.name, mode="w+", encoding="utf-8")
        )
        runner.run(test)
ta = Test()
ta.py ="testAdd.py"
ta.name="计算机加法测试报告.html"
ta.start()
ts = Test()
ts.py ="testSubs.py"
ts.name="计算机加减法试报告.html"
ts.start()
tm = Test()
tm.py ="testMulti.py"
tm.name="计算机乘法测试报告.html"
tm.start()
td = Test()
td.py ="testDevision.py"
td.name="计算机除法测试报告.html"
td.start()