from InitPage import LoginInitPage
from LoginOpera import LoginOpreation
from ddt import ddt
from ddt import data
from unittest import TestCase
from selenium import webdriver
import time
@ddt
class TestLogin(TestCase):

    def setUp(self) -> None: # 每个测试用例执行前必须执行执行这个方法
        self.driver = webdriver.Chrome()
        self.driver.get("http://localhost:8080/HKR")

    def tearDown(self) -> None: # 每个测试用例执行后执行
        time.sleep(5)
        self.driver.quit()

    @data(*LoginInitPage.login_success_data)
    def testLogin_success(self,testdata):
        # 提取数据
        username = testdata["username"]
        password = testdata["password"]
        expect =  testdata["expect"]

        # 操作
        login = LoginOpreation(self.driver)
        login.login(username,password)
        time.sleep(5)

        # 获取实际结果
        result = login.get_success_result()

        self.assertEqual(expect,result)
        # if result == expect:
        #     login.writ_excel_success(username,password,expect)
        # else:
        #     self.driver.save_screenshot("loginfail.jpg")
        #     login.writ_excel_error(username,password,expect)



    @data(*LoginInitPage.login_pwd_error_data)
    def testLogin_pwd_error(self,testdata):
        # 提取数据
        username = testdata["username"]
        password = testdata["password"]
        expect = testdata["expect"]

        # 操作
        login = LoginOpreation(self.driver)
        login.login(username,password)
        time.sleep(10)

        # 获取实际结果
        result = login.get_pwd_error_result()
        # 断言
        self.assertEqual(result,expect)
        # if result == expect:
        #     login.writ_excel_success(username,password,expect)
        # else:
        #     self.driver.save_screenshot("loginfail.jpg")
        #     login.writ_excel_error(username,password,expect)



















