def send():
    import smtplib
    from email.header import Header
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    # 发件人qq号
    sender = '1870934308@qq.com'
    # 收件人qq号
    receiver = '1870934308@qq.com'
    # 设置服务器
    smtpserver = "smtp.qq.com"
    # 登录邮箱的用户名
    username = '1870934308@qq.com'
    # 登录邮箱的密码
    password = 'zhuzpfbhtwtpcddc'
    # 邮件的标题
    mail_title = '登录测试报告'
    # 创建一个带附件的实例
    message = MIMEMultipart()
    # 加邮件头
    # 发送者账号
    message['From'] = Header("阮宏英<%s>" % sender, "utf-8")
    # 接收者账号
    message['To'] = receiver
    # 邮件主题
    message['Subject'] = Header(mail_title, 'utf-8')
    # 邮件正文内容
    message.attach(MIMEText('HKR登录测试邮件', 'plain', 'utf-8'))

    # 构造附件1（附件为TXT格式的文本）
    att1 = MIMEText(open('HKR.xlsx', 'rb').read(), 'base64', 'utf-8')
    att1["Content-Type"] = 'application/octet-stream'
    att1["Content-Disposition"] = 'attachment; filename="HKR.xlsx"'
    message.attach(att1)
    # 构造附件3（附件为HTML格式的网页）
    # 用Base64编码:
    att3 = MIMEText(open('HKR登录测试.html', 'rb').read(), 'base64', 'utf-8')
    # 设置请求内容类型
    att3["Content-Type"] = 'application/octet-stream'
    # 这里的filename可以任意写，写什么名字，邮件中显示什么名字
    att3["Content-Disposition"] = 'attachment; filename="HKRLogin.html"'
    message.attach(att3)
    try:
        #
        smtpObj = smtplib.SMTP()
        # SMTP协议默认端口是25 ，连接smtp服务器
        smtpObj.connect(smtpserver, 25)
        # 发送者的邮箱账号，密码，登录邮箱
        smtpObj.login(username, password)
        # 发送邮件
        smtpObj.sendmail(sender, receiver, message.as_string())
        smtpObj.quit()
        print("邮件发送成功")
    except smtplib.SMTPException:
        print("Error: 无法发送邮件")