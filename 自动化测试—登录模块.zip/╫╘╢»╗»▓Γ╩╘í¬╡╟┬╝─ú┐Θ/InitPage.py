import xlrd
'''
任务1：
    将数据集中放在excel表里，将实际测试结果写回带excel表里
任务2：
    HKR
'''

class  LoginInitPage:
    login_success_data = []
    login_pwd_error_data = []
    data = {}
    wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")
    st = wd.sheet_by_index(0)
    rows = st.nrows
    for i in range(1,rows):
        name = st.cell_value(i, 0)
        pwd = st.cell_value(i, 1)
        ex = st.cell_value(i, 2)
        if st.cell(i, 2).value == "Student Login":
            ture ={"username":name,"password":pwd,"expect":ex}
            login_success_data.append(ture)
        else:
            ture = {"username": name, "password": pwd, "expect": ex}
            login_pwd_error_data.append(ture)
    print(login_success_data)
    print(login_pwd_error_data)

















