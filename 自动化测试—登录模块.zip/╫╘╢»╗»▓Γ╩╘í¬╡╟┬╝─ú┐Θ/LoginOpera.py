
from openpyxl import load_workbook
import xlrd
class LoginOpreation:

    def __init__(self,driver): # 全局方法，
        self.driver = driver
        self.driver.maximize_window()

    # 只做页面的登陆操作
    def login(self,username,password):
        self.driver.find_element_by_xpath("//*[@id='loginname']").send_keys(username)

        self.driver.find_element_by_xpath("//*[@id='password']").send_keys(password)

        self.driver.find_element_by_xpath("//*[@id='submit']").click()


    def get_success_result(self):
        return self.driver.title


    def get_pwd_error_result(self):
        return self.driver.find_element_by_xpath("//*[@id='msg_uname']").text

    def writ_excel_success(self,username,password,expect):
        wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")
        st = wd.sheet_by_index(0)
        rows = st.nrows
        for i in range(1, rows):
            name = st.cell_value(i, 0)
            pwd = st.cell_value(i, 1)
            ex = st.cell_value(i, 2)
            if name == username and pwd == password and ex == expect:
                wb = load_workbook(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")  # 生成一个已存在的wookbook对象
                wb1 = wb.active  # 激活sheet
                wb1.cell(i + 1, 4, '通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
                wb.save(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")  # 保
            else:
                continue
    def writ_excel_error(self,username,password,expect):
        wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")
        st = wd.sheet_by_index(0)
        rows = st.nrows
        for i in range(1, rows):
            name = st.cell_value(i, 0)
            pwd = st.cell_value(i, 1)
            ex = st.cell_value(i, 2)
            if name == username and pwd == password and ex == expect:
                wb = load_workbook(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")  # 生成一个已存在的wookbook对象
                wb1 = wb.active  # 激活sheet
                wb1.cell(i + 1, 4, '不通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
                wb.save(r"D:\python\autoweb03\自动化测试—登录模块\HKR.xlsx")  # 保
            else:
                continue





















