from unittest import TestCase
from ddt import ddt
from ddt import data
from ddt import unpack
from InitPage import SelectInitPage
from SelectOpera import SelectOperation
import time
from selenium import webdriver
@ddt
class TestSelect(TestCase):
    # 每个测试用例执行前必须执行执行这个方法
    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.get("http://localhost:8080/HKR/")
        self.driver.find_element_by_xpath("/html/body/div/div/div[1]/div[2]/a[2]").click()
        self.driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
        self.driver.find_element_by_xpath("//*[@id='password']").send_keys("admin")
        self.driver.find_element_by_xpath("//*[@id='submit']").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='_easyui_tree_12']/span[4]/a").click()
        time.sleep(5)
    # 每个测试用例执行后执行
    def tearDown(self) -> None:
        time.sleep(5)
        self.driver.quit()

    @data(*SelectInitPage.Select_success_data)
    def testSelect_success(self,testdata):
        # 提取数据
        username = testdata["username"]
        #phone = testdata["phone"]
        expety = testdata["expety"]
        print(expety)
        # 操作
        select = SelectOperation(self.driver)
        select.select(username)
        time.sleep(5)
        # 实际结果
        result =select.get_success_result()
        print(result)
        time.sleep(2)
        #断言
        self.assertEqual(expety,result)








