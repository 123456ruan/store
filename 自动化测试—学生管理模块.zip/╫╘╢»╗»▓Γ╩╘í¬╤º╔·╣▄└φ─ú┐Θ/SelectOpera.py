import time
from selenium.webdriver.common.by import By
class SelectOperation:

    def __init__(self,driver):
        self.driver = driver
    def select(self,username):
        # 输入用户名
        self.driver.find_element_by_xpath("//input[@id='J-stu']").send_keys(username)
        # 输入密码
        # self.driver.find_element_by_xpath("//input[@id='J-phone']").send_keys(phone)
        # time.sleep(3)
        # 点击查询
        self.driver.find_element_by_xpath("//*[@id='stu_panel']/div/div/div[1]/table/tbody/tr/td[4]/a").click()
        time.sleep(3)


    # 实际结果
    def get_success_result(self):
        #tr = self.driver.find_element_by_xpath("//*[@id='stu_panel']/div/div/div[2]/div[2]/div[2]/table/tbody").text
        table_loc = (By.XPATH, "//*[@id='stu_panel']/div/div/div[2]/div[2]/div[2]/table/tbody")
        table_tr_list = self.driver.find_element(*table_loc).find_elements(By.TAG_NAME, "tr")
        arr = []
        list = []
        for i in table_tr_list:
            arr1 = (i.text).split("\n")
            arr.append(arr1)
        for k in arr:
            for j in range(len(k)):
                k[j].replace('\\n', '')#.replace('\r', '')
            list.append(k)
        return list

