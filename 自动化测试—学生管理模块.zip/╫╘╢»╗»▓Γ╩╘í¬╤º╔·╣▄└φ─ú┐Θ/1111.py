from selenium import webdriver
import time
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("http://localhost:8080/HKR/")
driver.find_element_by_xpath("/html/body/div/div/div[1]/div[2]/a[2]").click()
driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
driver.find_element_by_xpath("//*[@id='password']").send_keys("admin")
driver.find_element_by_xpath("//*[@id='submit']").click()
time.sleep(3)
driver.find_element_by_xpath("//*[@id='_easyui_tree_12']/span[4]/a").click()
time.sleep(5)
driver.find_element_by_xpath('//*[@id="J-stu"]').send_keys("jason")
# driver.find_element_by_xpath("//input[@id='J-phone']").send_keys("13548554150")
driver.find_element_by_xpath("//*[@id='stu_panel']/div/div/div[1]/table/tbody/tr/td[4]/a").click()
time.sleep(3)
# 定位使用路径定位
table_loc = (By.XPATH,"//*[@id='stu_panel']/div/div/div[2]/div[2]/div[2]/table/tbody")
# 获取该路径的所有tr里面的值
table_tr_list = driver.find_element(*table_loc).find_elements(By.TAG_NAME,"tr")
arr = []
list = []
for i in table_tr_list:
    arr1 = (i.text).split("\n")
    arr.append(arr1)
for k in arr:
    for j in range(len(k)):
        k[j]#.replace('\n', '').replace('\r', '')
    print(k)
    list.append(k)
# print(list)
print(arr)
time.sleep(5)
driver.quit()