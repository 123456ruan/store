import time
from selenium.webdriver.support.select import Select




class Evaluationperation:

    def __init__(self,driver):
        self.driver = driver
    def insert(self,teacher):
        ele2 = self.driver.find_element_by_xpath("//*[@id='tea_td']/select")
        Select(ele2).select_by_value(teacher)
        self.driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[6]/td[2]/div/label[2]/div").click()
        self.driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[9]/td[2]/div/label[3]/div").click()
        self.driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[11]/td[2]/div/label[4]/div").click()
        time.sleep(5)
        self.driver.find_element_by_xpath("//*[@id='subtn']").click()
    # 实际结果
    def get_success_result(self):
        return self.driver.find_element_by_xpath("/html/body/div[7]/div[2]/div[2]").text

    # 实际结果
    def get_error_result(self):
        return self.driver.find_element_by_xpath("/html/body/div[7]/div[2]/div[2]").text