




class EvaluationInitPage:
    Evaluation_success_data = [{"teacher":"李艳","expect":"提交成功！"}]
    Evaluation_error_data = [{"teacher":"李艳","expect":"您今日已对该老师进行了评价,请勿重复评价！"},
                             {"teacher":"陈永杰","expect":"您今日已对该老师进行了评价,请勿重复评价！"},
                             {"teacher":"贾生","expect":"您今日已对该老师进行了评价,请勿重复评价！"}]