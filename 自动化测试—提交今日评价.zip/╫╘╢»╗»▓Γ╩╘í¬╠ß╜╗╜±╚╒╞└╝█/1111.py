from selenium import webdriver
from selenium.webdriver.support.select import Select
import time

driver = webdriver.Chrome()
driver.get("http://localhost:8080/HKR/")
driver.maximize_window()
driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
driver.find_element_by_xpath("//*[@id='password']").send_keys("1234567")
driver.find_element_by_xpath("//*[@id='submit']").click()
time.sleep(5)
# ele1 = driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[2]/td[2]/select")
# Select(ele1).select_by_value("7（没有晚自习）")
ele2 = driver.find_element_by_xpath("//*[@id='tea_td']/select")
Select(ele2).select_by_value("贾生")
driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[6]/td[2]/div/label[2]/div").click()
driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[9]/td[2]/div/label[3]/div").click()
driver.find_element_by_xpath("//*[@id='form_table']/tbody/tr[11]/td[2]/div/label[4]/div").click()
time.sleep(5)
driver.find_element_by_xpath("//*[@id='subtn']").click()
time.sleep(2)
driver.find_element_by_xpath("/html/body/div[7]/div[3]/a").click()

