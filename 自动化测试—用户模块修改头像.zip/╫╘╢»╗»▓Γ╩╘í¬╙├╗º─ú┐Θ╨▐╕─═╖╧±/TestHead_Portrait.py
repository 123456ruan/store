from unittest import TestCase
from selenium import webdriver
from ddt import ddt
from ddt import data
from ddt import unpack
from InitPage import Head_PortraitInitPage
from UpdateHead_PortraitOpera import Upadteperation
import time
@ddt
class TestHkr(TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get("http://localhost:8080/HKR/")
        self.driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
        self.driver.find_element_by_xpath("//*[@id='password']").send_keys("1234567")
        self.driver.find_element_by_xpath("//*[@id='submit']").click()
        time.sleep(5)
        self.driver.find_element_by_xpath("//*[@id='img']").click()
        time.sleep(5)

    def tearDown(self) -> None:  # 每个测试用例执行后执行
        time.sleep(5)
        self.driver.quit()

    @data(*Head_PortraitInitPage.Head_PortraitInitPage_data)
    def testUpdateHead_portrait_success(self, testdata):
        # 提取数据
        picturePath = testdata["picturePath"]
        expect = testdata["expect"]

        # 操作
        update = Upadteperation(self.driver)
        update.insert(picturePath)
        time.sleep(5)

        # 获取实际结果
        result = update.get_success_result()

        self.assertEqual(expect, result)
        # if result == expect:
        #     Insert.writ_excel_success(username,descri,expect)
        # else:
        #     self.driver.save_screenshot("loginfail.jpg")
        #     Insert.writ_excel_error(username,descri,expect)