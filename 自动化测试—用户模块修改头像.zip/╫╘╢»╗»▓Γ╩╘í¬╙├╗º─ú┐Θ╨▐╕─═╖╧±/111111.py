from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get("http://localhost:8080/HKR/")
driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
driver.find_element_by_xpath("//*[@id='password']").send_keys("1234567")
driver.find_element_by_xpath("//*[@id='submit']").click()
time.sleep(5)
driver.find_element_by_xpath("//*[@id='img']").click()
time.sleep(5)
driver.find_element_by_xpath("//*[@id='ul_pic']/li[4]/img").click()
time.sleep(5)
driver.quit()