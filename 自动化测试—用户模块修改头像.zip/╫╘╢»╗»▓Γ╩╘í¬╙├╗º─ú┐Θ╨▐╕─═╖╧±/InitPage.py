



class Head_PortraitInitPage:

    Head_PortraitInitPage_data =[{"picturePath":"狗子","expect":"成功修改头像!"},
                                 # {"picturePath": "img/picture/meng.jpg","expect":"成功修改头像!"}
                                 ]
