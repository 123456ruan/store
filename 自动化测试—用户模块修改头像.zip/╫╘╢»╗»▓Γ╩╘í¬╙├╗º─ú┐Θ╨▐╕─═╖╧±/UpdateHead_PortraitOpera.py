import time
from openpyxl import load_workbook

import xlrd
class Upadteperation:


    def __init__(self,driver):
        self.driver = driver
    def insert(self,picturePath):
        self.driver.find_element_by_xpath("//li[@title='"+ picturePath +"']").click()
        time.sleep(3)
    # 实际结果
    def get_success_result(self):
        return  self.driver.find_element_by_xpath("/html/body/div[7]").text
    # def writ_excel_success(self,username,descri,expect):
    #     wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")
    #     st = wd.sheet_by_index(0)
    #     rows = st.nrows
    #     for i in range(1, rows):
    #         name = st.cell_value(i, 0)
    #         pwd = st.cell_value(i, 1)
    #         ex = st.cell_value(i, 2)
    #         if name == username and pwd == descri and ex == expect:
    #             wb = load_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 生成一个已存在的wookbook对象
    #             wb1 = wb.active  # 激活sheet
    #             wb1.cell(i + 1, 4, '通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
    #             wb.save(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 保
    #         else:
    #             continue
    # def writ_excel_error(self,username,descri,expect):
    #     wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")
    #     st = wd.sheet_by_index(0)
    #     rows = st.nrows
    #     for i in range(1, rows):
    #         name = st.cell_value(i, 0)
    #         pwd = st.cell_value(i, 1)
    #         ex = st.cell_value(i, 2)
    #         if name == username and pwd == descri and ex == expect:
    #             wb = load_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 生成一个已存在的wookbook对象
    #             wb1 = wb.active  # 激活sheet
    #             wb1.cell(i + 1, 4, '通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
    #             wb.save(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 保
    #         else:
    #             continue