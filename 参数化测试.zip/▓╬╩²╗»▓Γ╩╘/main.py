import unittest
from HTMLTestRunner import HTMLTestRunner
import os
from threading import Thread
testAdd = unittest.defaultTestLoader.discover(os.getcwd(),pattern="testAdd.py")
testSubs = unittest.defaultTestLoader.discover(os.getcwd(),pattern="testSubs.py")
testMulti = unittest.defaultTestLoader.discover(os.getcwd(),pattern="testMulti.py")
testDevision = unittest.defaultTestLoader.discover(os.getcwd(),pattern="testDevision.py")
runneradd = HTMLTestRunner.HTMLTestRunner(
    title="计算器测试报告",
    description="计算器的加法测试报告",
    verbosity=1,
    stream=open(file="计算器加法测试报告.html",mode="w+",encoding="utf-8")
)
runnersubs = HTMLTestRunner.HTMLTestRunner(
    title="计算器测试报告",
    description="计算器的减法测试报告",
    verbosity=1,
    stream=open(file="计算器减法测试报告.html",mode="w+",encoding="utf-8")
)
runnermulti = HTMLTestRunner.HTMLTestRunner(
    title="计算器测试报告",
    description="计算器的乘法测试报告",
    verbosity=1,
    stream=open(file="计算器乘法测试报告.html",mode="w+",encoding="utf-8")
)
runnerdevision = HTMLTestRunner.HTMLTestRunner(
    title="计算器测试报告",
    description="计算器的除法测试报告",
    verbosity=1,
    stream=open(file="计算器除法测试报告.html",mode="w+",encoding="utf-8")
)
class TestAdd(Thread):
    def run(self) -> None:
        runneradd.run(testAdd)
class TestTSubs(Thread):
    def run(self) -> None:
        runnersubs.run(testSubs)
class TestMulti(Thread):
    def run(self) -> None:
        runnermulti.run(testMulti)
class TestDevision(Thread):
    def run(self) -> None:
        runnerdevision.run(testDevision)

ta = TestAdd()
ts = TestTSubs()
tm = TestMulti()
td = TestDevision()
ta.start()
ts.start()
tm.start()
td.start()
