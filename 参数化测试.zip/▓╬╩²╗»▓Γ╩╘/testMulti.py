from unittest import TestCase
from ddt import ddt
from ddt import  data
from ddt import unpack
from Calc import Calc

da = [
    [1,2,2],
    [5,6,30],
    [-9,8,-72],
    [-9,-9,81],
    [0,0,0],
    [50000000000000,1,50000000000000],
    [10,10,100]
]
@ddt()
class testCalc(TestCase):
    @data(*da)
    @unpack
    def testMulti(self,a,b,c):
        calc = Calc()
        sum = calc.multi(a,b)
        self.assertEqual(sum,c)
