from unittest import TestCase
from ddt import ddt
from ddt import  data
from ddt import unpack
from Calc import Calc

da = [
    [2,2,1],
    [6,6,1],
    [-9,3,-3],
    [-9,-9,1],
    [0,0,0],
    [50000000000000,1,50000000000000],
    [0,10,0]
]
@ddt()
class testCalc(TestCase):
    @data(*da)
    @unpack
    def testDevision(self,a,b,c):
        calc = Calc()
        sum = calc.devision(a,b)
        self.assertEqual(sum,c)
