import  pymysql
host = "localhost"
user = "root"
password = "root"
database = "hkr"
# 查询
def select(sql,param):
    con = pymysql.connect(host=host, user=user, password=password, database=database)
    cursor = con.cursor()
    cursor.execute(sql,param)
    return cursor.fetchall()
    cursor.close()
    con.close()
def select2(sql,param):
    con = pymysql.connect(host=host, user=user, password=password, database=database)
    cursor = con.cursor()
    return cursor.execute(sql,param)
    cursor.close()
    con.close()

