import xlrd


class InsertInitPage:
    Insert_success_data = []
    Insert_error_data = []
    wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")
    st = wd.sheet_by_index(0)
    rows = st.nrows
    for i in range(1, rows):
        name = st.cell_value(i, 0)
        pwd = st.cell_value(i, 1)
        ex = st.cell_value(i, 2)
        if ex == "1":
            ture = {"username": name, "descri": pwd, "expect": ex}
            Insert_success_data.append(ture)
        else:
            ture = {"username": name, "descri": pwd, "expect": ex}
            Insert_error_data.append(ture)
    print(Insert_success_data)
    print(Insert_error_data)





    # Insert_success_data=[{"username":"接口测试2", "descri":"2222222222", "expect":1},
    #                       {"username":"接口测试3", "descri":"3333333333", "expect":1}
    #                       ]