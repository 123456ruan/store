import time
from openpyxl import load_workbook
from DBUtils import select2
import xlrd
class Insertperation:


    def __init__(self,driver):
        self.driver = driver
    def insert(self,username,descri):
        self.driver.find_element_by_xpath("//*[@id='course_form_add']/table/tbody/tr[1]/td[2]/input").send_keys(username)
        self.driver.find_element_by_xpath("//*[@id='course_form_add']/table/tbody/tr[2]/td[2]/textarea").send_keys(
            descri)
        self.driver.find_element_by_xpath("/html/body/div[7]/div[3]/a[1]").click()
        time.sleep(3)
    # 实际结果
    def get_success_result(self,username):
        sql1 = "select * from t_course where courseName = %s"
        if select2(sql1,username) != 0:
            return "1"
        return 0

    # 实际结果
    def get_error_result(self):
        return  self.driver.find_element_by_xpath("/html/body/div[10]/div[2]/div[2]").text

    def writ_excel_success(self,username,descri,expect):
        wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")
        st = wd.sheet_by_index(0)
        rows = st.nrows
        for i in range(1, rows):
            name = st.cell_value(i, 0)
            pwd = st.cell_value(i, 1)
            ex = st.cell_value(i, 2)
            if name == username and pwd == descri and ex == expect:
                wb = load_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 生成一个已存在的wookbook对象
                wb1 = wb.active  # 激活sheet
                wb1.cell(i + 1, 4, '通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
                wb.save(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 保
            else:
                continue
    def writ_excel_error(self,username,descri,expect):
        wd = xlrd.open_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")
        st = wd.sheet_by_index(0)
        rows = st.nrows
        for i in range(1, rows):
            name = st.cell_value(i, 0)
            pwd = st.cell_value(i, 1)
            ex = st.cell_value(i, 2)
            if name == username and pwd == descri and ex == expect:
                wb = load_workbook(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 生成一个已存在的wookbook对象
                wb1 = wb.active  # 激活sheet
                wb1.cell(i + 1, 4, '通过')  # 往sheet中的第二行第二列写入‘pass2’的数据
                wb.save(r"D:\python\autoweb03\自动化测试—课程管理模块\课程管理数据.xlsx")  # 保
            else:
                continue