from unittest import TestCase
from selenium import webdriver
from ddt import ddt
from ddt import data
from ddt import unpack
from InitPage import InsertInitPage
from InsertOpera import Insertperation
import time
@ddt
class TestHkr(TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get("http://localhost:8080/HKR")
        self.driver.find_element_by_xpath("/html/body/div/div/div[1]/div[2]/a[2]").click()
        self.driver.find_element_by_xpath("//*[@id='loginname']").send_keys("jason")
        self.driver.find_element_by_xpath("//*[@id='password']").send_keys("admin")
        self.driver.find_element_by_xpath("//*[@id='submit']").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='_easyui_tree_13']/span[4]").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='course_panel']/div/div/div[1]/table/tbody/tr/td/a").click()

    def tearDown(self) -> None:  # 每个测试用例执行后执行
        time.sleep(5)
        self.driver.quit()

    @data(*InsertInitPage.Insert_success_data)
    def testInsert_success(self, testdata):
        # 提取数据
        username = testdata["username"]
        descri = testdata["descri"]
        expect = testdata["expect"]

        # 操作
        Insert = Insertperation(self.driver)
        Insert.insert(username,descri)
        time.sleep(5)

        # 获取实际结果
        result = Insert.get_success_result(username)

        self.assertEqual(expect, result)
        # if result == expect:
        #     Insert.writ_excel_success(username,descri,expect)
        # else:
        #     self.driver.save_screenshot("loginfail.jpg")
        #     Insert.writ_excel_error(username,descri,expect)

    @data(*InsertInitPage.Insert_error_data)
    def testInsert_error(self, testdata):
        # 提取数据
        username = testdata["username"]
        descri = testdata["descri"]
        expect = testdata["expect"]

        # 操作
        Insert = Insertperation(self.driver)
        Insert.insert(username, descri)
        time.sleep(5)

        # 获取实际结果
        result = Insert.get_error_result()

        self.assertEqual(expect, result)
        # if result == expect:
        #     Insert.writ_excel_success(username,descri,expect)
        # else:
        #     self.driver.save_screenshot("loginfail.jpg")
        #     Insert.writ_excel_error(username,descri,expect)