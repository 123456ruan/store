import unittest
from HTMLTestRunner import HTMLTestRunner
import os

test = unittest.defaultTestLoader.discover(os.getcwd(),pattern= "Test*.py")
runner = HTMLTestRunner.HTMLTestRunner(
    title="课程管理测试",
    description="包含失败或没失败",
    verbosity=1,
    stream=open(file="HKR课程管理测试.html", mode="w+", encoding="utf-8")

)
runner.run(test)